import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AdminSupportService {
  private baseUrl = `${environment.apiBaseUrl}/admin/support`;

  private ticketsSubject = new Subject<any>();
  tickets$ = this.ticketsSubject.asObservable();

  private lastParams: any = null;

  constructor(private http: HttpClient) {}

  getTickets(params?: any) {
    return this.http.get(`${this.baseUrl}/tickets`, { params });
  }

  fetchTicketsReactive(params: any): Observable<any> {
    if (JSON.stringify(this.lastParams) === JSON.stringify(params)) {
      return this.tickets$;
    }

    this.lastParams = params;

    return this.http.get(`${this.baseUrl}/tickets`, { params });
  }

  getTicketById(id: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/tickets/${id}`);
  }

  replyToTicket(id: string, message: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/tickets/${id}/reply`, { message });
  }

  updateStatus(id: string, status: string): Observable<any> {
    return this.http.patch(`${this.baseUrl}/tickets/${id}/status`, { status });
  }

  getCounts() {
    return this.http.get(`${this.baseUrl}/tickets/count`);
  }
}
