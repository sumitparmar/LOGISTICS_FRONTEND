import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router,
} from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(
    private authService: AuthService,
    private router: Router,
  ) {}

  canActivate(_: ActivatedRouteSnapshot, __: RouterStateSnapshot): boolean {
    if (this.authService.hasToken()) {
      return true;
    }

    // Not logged in; redirect to login
    this.router.navigate(['/auth/login']);
    return false;
  }
}
